<?php

$uri = $_SERVER['REQUEST_URI'];
// Save the URI to the session
$_SESSION['saved_addr'] = $uri;

$m1["content"]="";
$q = "SELECT * FROM articles WHERE  cat='111' and status='1' ORDER BY mdate  Limit 1";
$r = mysqli_query($conn, $q) or die(mysqli_error($conn));
$mid = mr($r, 0, "id");

$num_rows = mysqli_num_rows($r);
$fb_text=$str["s_fb_title_about_us"];
$fb_site_desc=$str["s_fb_desc_about_us"];

for ($i = 0; $i < $num_rows; $i++) {
    $fid = mr($r, $i, "front_id");
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl_num_rows = mysqli_num_rows($rl);

    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
        $pname = mr($rl, 0, "pname");
        $fid = mr($r, 0, "front_id");
        $meta_name = mr($rl, 0, "mname");
        $meta_desc = mr($rl, 0, "mdesc");
    } else {
        $mtitle = mr($rl, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        $pname = mr($r, $i, "pname");
        $fid = mr($r, $i, "front_id");
        $meta_name = mr($r, $i, "mname");
        $meta_desc = mr($r, $i, "mdesc");
    }
    if ($mtitle == "") {
        continue;
    } else {
        $m2["title"] = $mtitle;
        $m2["mtext"] = $mtext;
        $m2["pname"] = $pname;
        $m2["mtext"]=str_replace("[a]","'",$m2["mtext"]);
        $m2["pname"]=str_replace("[a]","'",$m2["pname"]);
        $m2["title"]=str_replace("[a]","'",$m2["title"]);
        $m2["lang"]=$lang;
        $m2["link"]="?m=articles&id=".$fid;

        $m1["meta_name"]=$meta_name;
        $m1["meta_description"]=$meta_desc;


        $fb_site_desc=str_replace('"',"",$m2["title"]);
        $fb_url=$main_domain."?m=about_us_page&lang=1";
        $m2["fb_url"]=urlencode($fb_url);
        
        $mid = mr($r, $i, "id");
        $thumb = get_file($mid,1);
        $m2["thumb"] = $thumb;

        $fixed_url = preg_replace('#(?<!https:)//+#', '/', $thumb);


        $fb_image=$fixed_url;

        $fb_text=$mtitle;
        $mtextfb = str_replace('"','',$mtext);

        $fb_site_desc=$mtextfb;

        $gallery=build_gallery($mid, 4);

        $thumb_desc=get_file_desc($mid, 4);
        $thumb_descm=get_file_desc($mid, 1);

        $m2["thumb_desc"]=$thumb_desc;
        $m2["thumb_descm"]=$thumb_descm;

     
        $m2["mtext"]=str_replace("[gallery]",$gallery,$m2["mtext"]);
        $m2["pname"]=str_replace("[gallery]",$gallery,$m2["pname"]);


    }
}
include "about_us_staff.php";
include "about_us_partners.php";



$m1["content"].=load_template("about_us_page",$m2);

if($lang == 1){
    $breadname = 'ჩვენ შესახებ';
    $fb_image=$main_domain."/images/futureevents-fb.jpg";
}
else{
    $breadname = 'ABOUT US';
    $fb_image=$main_domain."/images/futureevents-fb.jpg";
}

$fb_url='https://teatri.ge/aboutuspage/';

$breadcrumbItem = [
    '@type' => 'ListItem',
    'position' => 2,
    'item' => [
        '@id' => 'https://teatri.ge/aboutuspage/',
        'name' => $breadname 
    ]
];
array_push($breadcrumbList['itemListElement'], $breadcrumbItem);




?>