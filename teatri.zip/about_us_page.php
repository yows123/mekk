<?php
$m3["about_us_page"]="";
$r=mysqli_query($conn, "SELECT * FROM articles WHERE cat='10' and status='1' ORDER BY mdate DESC, id DESC ") or die(mysqli_error($conn));
for ($i=0;$i<mysqli_num_rows($r);$i++) {
    $fid=mr($r, $i, "front_id");
    $rl=mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    if (mysqli_num_rows($rl)>0){
        $mtitle=mr($rl, 0, "mtitle");
        $mtext=mr($rl, 0, "mtext");
    } else {
        $mtitle=mr($r, $i, "mtitle");
        $mtext=mr($r, $i, "mtext");
    }
    $m2["title"]=$mtitle;
    $m2["mtext"]=$mtext;
    
    $m2["mtext"]=str_replace("[a]","'",$m2["mtext"]);
    $m2["title"]=str_replace("[a]","'",$m2["title"]);
    $m2["lang"]=$lang;

    $a=explode("[more]",$m2["mtext"]);
    if (count($a)>1){
        $m2["mtext"]=$a[0];
    }
    $m2["mtext"]=str_replace("&nbsp;"," ",$m2["mtext"]);

    $mid=mr($r, $i, "id");
    $thumb=get_file($mid,1);
    $m2["thumbnail"]=$thumb;
    $mdate=mr($r, $i, "mdate");
    $md=explode(" ",$mdate);
    $mdate=$md[0];
    $mdate = date("d.m.Y", strtotime($mdate));
    $mdate=$mdate;
    $md=explode(" ",$mdate);
    $mdate=$md[0];
    $fid=mr($r, $i, "front_id");
    $link=mr($r, $i, "link");
    $gallery=build_gallery($mid, 2);
		
    $m3["mtext"]=str_replace("[gallery]",$gallery,$m3["mtext"]);

    //$fb_text=str_replace('"',"",$m2["title"]);
    $fb_site_desc=str_replace('"',"",$m2["title"]);
    //$fb_site_desc=str_replace('"',"",$m2["mtext"]);
	$fb_image=$thumb;

    
    $fb_url=$main_domain."?m=about_us_page&lang=1";
	$m2["fb_url"]=urlencode($fb_url);
    $m2["mdate"]=$mdate;
    $m2["id"]=$fid;
    $m2["shida_link"]="?m=about_us_page&lang=1";
 
   
    //$m1["partners_item"].=load_template("home_partners_item",$m2);

}
//include "about_us_partners.php";

$m3["about_us_page"].=load_template("about_us_page", $m1);
