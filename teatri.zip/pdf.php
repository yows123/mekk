<?php
//include "includes/func.php";
ob_end_clean();

ob_start();

ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once('vendor/tecnickcom/tcpdf/tcpdf.php');  // Adjust the path accordingly if you've installed TCPDF manually.

// Create new PDF
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// Set document information
//$pdf->SetCreator(PDF_CREATOR);
//$pdf->SetAuthor('Your Company');
$pdf->SetTitle('Invoice');
//$pdf->SetSubject('Invoice');
//$pdf->SetKeywords('invoice');

// Set header data
$pdf->setPrintHeader(false);

// Set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// Set default monospaced font
//$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// Set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
$pdf->SetMargins(PDF_MARGIN_LEFT, 5, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(0);

// Set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// Add a page
$pdf->AddPage();
// Set font
$pdf->SetFont('dejavusans', '', 12); // Use DejaVuSans font


// Invoice content




$pdf->writeHTML($html, true, false, true, false, '');
ob_end_clean();

$pdf->Output('invoice.pdf', 'I');

?>