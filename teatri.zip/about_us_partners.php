<?php
$m2["partners_item"] = "";
$q = "SELECT * FROM articles WHERE  cat='501' and status='1' ORDER BY mdate  Limit 30";
$r = mysqli_query($conn, $q) or die(mysqli_error($conn));

$num_rows = mysqli_num_rows($r);

$m3["p_title"]="";
$m3["p_mtext"]="";
$m3["p_lang"]="";
$m3["p_link"]="";
$m3["p_thumb"]="";

for ($i = 0; $i < $num_rows; $i++) {
    $fid = mr($r, $i, "front_id");
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl_num_rows = mysqli_num_rows($rl);

    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
        $fid = mr($r, 0, "front_id");
        $link = mr($rl, 0, "link");
    } else {
        $mtitle = mr($rl, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        $fid = mr($r, $i, "front_id");
        $link = mr($rl, $i, "link");
    }

    if ($mtitle == "") {
        continue;
    } else {
        $m3["p_title"] = $mtitle;
        $m3["p_mtext"] = $mtext;
        $m3["p_mtext"]=str_replace("[a]","'",$m3["p_mtext"]);
        $m3["p_title"]=str_replace("[a]","'",$m3["p_title"]);
        $m3["p_lang"]=$lang;
        $m3["p_link"]=$link;

        $mid = mr($r, $i, "id");
        $thumb = get_file($mid,1);

        $m3["p_thumb"] = $thumb;

        $thumb_desc=get_file_desc($mid, 1);
        $m3["thumb_desc"]=$thumb_desc;

        
        $m2["partners_item"].=load_template("home_partners_item",$m3);
    }
}



?>