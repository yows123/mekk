<?php
$m1["content"]="";
$mtext='';
$q = "SELECT * FROM articles WHERE  pid='$pid' and status='1' ";
$r = mysqli_query($conn, $q) or die(mysqli_error($conn));
$m3["mtext"]="";
$num_rows = mysqli_num_rows($r);

$m1["meta_name"]=$meta_name;
$m1["meta_description"]=$meta_desc;

for ($i = 0; $i<$num_rows; $i++) {
    $fid = mr($r, $i, "front_id");
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl_num_rows = mysqli_num_rows($rl);
    $m2["mtext"] = $mtext;
    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
       // $pname = mr($rl, 0, "pname");
        $fid = mr($r, 0, "front_id");
        $mid = mr($r, 0, "id");
        $link_en = mr($r, 0, "link_en");
        $meta_name = mr($rl, 0, "mname");
        $meta_desc = mr($rl, 0, "mdesc");

    } else {
        $mtitle = mr($rl, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        //$pname = mr($r, $i, "pname");
        $fid = mr($r, $i, "front_id");
        $mid = mr($rl, $i, "id");
        $link_en = mr($rl, $i, "link_en");
        $meta_name = mr($rl, $i, "mname");
        $meta_desc = mr($rl, $i, "mdesc");

    }
   
    $m2["title"] = $mtitle;
    $m2["mtext"] = $mtext;
    //$m2["pname"] = $pname;
    if($link_en != ""){
    $m2["style"] = $link_en;
    }
    else{
    $m2["style"] = "";
    }
    $m2["mtext"]=str_replace("[a]","'",$m2["mtext"]);

    //$m2["pname"]=str_replace("[a]","'",$m2["pname"]);
    $m2["title"]=str_replace("[a]","'",$m2["title"]);
    $gallery=build_gallery($mid, 4);

    $m2["mtext"]=str_replace("[gallery]",$gallery,$m2["mtext"]);

    $m2["lang"]=$lang;
    $m2["link"]="?m=privacy&id=".$fid;
    $fb_site_desc=str_replace('"',"",$m2["title"]);
    //$fb_site_desc=str_replace('"',"",$m2["mtext"]);
    $fb_url=$main_domain."?m=about_us_page&lang=1";
    $m2["fb_url"]=urlencode($fb_url);
    
    // $thumb = get_file($mid,1);
    // $m2["thumb"] = $thumb;

       
    }

    $fb_url='https://teatri.ge/'.$fid.'/'; 
    $fb_image=$main_domain.'/images/'.$fid.'-fb.jpg';
       
       
    	
$m1["meta_name"]=$meta_name;
$m1["meta_description"]=$meta_desc;

$m1["content"].=load_template("text_page",$m2);

?>