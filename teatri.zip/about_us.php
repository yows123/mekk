<?php
$m1["about_us"] = "";
$q = "SELECT * FROM articles WHERE  cat='111' and status='1' ORDER BY mdate  Limit 1";
$r = mysqli_query($conn, $q) or die(mysqli_error($conn));

$num_rows = mysqli_num_rows($r);


for ($i = 0; $i < $num_rows; $i++) {
    $fid = mr($r, $i, "front_id");
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl_num_rows = mysqli_num_rows($rl);

    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
        $fid = mr($r, 0, "front_id");
    } else {
        $mtitle = mr($rl, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        $fid = mr($r, $i, "front_id");
    }

    if ($mtitle == "") {
        continue;
    } else {
        $m2["title"] = $mtitle;
        $m2["mtext"] = $mtext;
        $m2["mtext"]=str_replace("[a]","'",$m2["mtext"]);
        $m2["title"]=str_replace("[a]","'",$m2["title"]);
        $m2["lang"]=$lang;
        $m2["link"]="?m=about_us&id=".$fid;

        $mid = mr($r, $i, "id");
        $thumb = get_file($mid,1);
        $m2["thumb"] = $thumb;


    }
}


include "about_us_partners.php";

$m1["about_us"].=load_template("about_us",$m2);


?>