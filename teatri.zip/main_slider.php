<?php
$m1["main_slider"] = "";

$current_datetime = date('Y-m-d H:i:s');

$q = "SELECT * FROM articles WHERE  cat='87' and status = '1' ORDER BY mdate DESC, id DESC";

$r = mysqli_query($conn, $q) or die(mysqli_error($conn));
//$arr = ['first','second','third'];
$num_rows = mysqli_num_rows($r);

$m2["slider_items"]="";
for ($i = 0; $i < $num_rows; $i++) {
    
    $fid = mr($r, $i, "front_id");
    $is_news = mr($r, $i, "is_news");
      
    $link =mr($r, $i, "link");
    $link_en =mr($r, $i, "link_en");
    $link_ru =mr($r, $i, "link_ru");
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl_num_rows = mysqli_num_rows($rl);

    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
        $fid = mr($rl, 0, "front_id");

    } else {
        $mtitle = mr($r, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        $fid = mr($r, $i, "front_id");
      
      
    }
    $mdate=mr($r, $i, "mdate");
    if ($lang == 1){
        $m3['mainlink'] = $link;
    }
    elseif ($lang == 2) {
        $m3['mainlink'] = $link_en;
    } else {
        $m3['mainlink'] = $link_ru;
    }

    if ($is_news==1){
        $m3["date_visible"]="";
    } else {
        $m3["date_visible"]="display:none;";
    }

    $m3["title"] = $mtitle;
    $m3["mtext"] = $mtext;
    $m3["mtext"]=str_replace("[a]","'",$m3["mtext"]);
    $m3["title"]=str_replace("[a]","'",$m3["title"]);
    $m3["lang"]=$lang;
    $mid = mr($r, $i, "id");
    $thumb = get_file($mid,1);
    $thumb2 = get_file($mid,2);

	$thumb_desc=get_file_desc($mid, 1);
	$m3["thumb_desc"]=$thumb_desc;

    if ($mdate!=""){
        $md=explode(" ",$mdate);
        $etime = $md[1];
        $etime = explode(":",$etime);
        $etime = $etime[0].":".$etime[1]; 
        $md=explode("-",$md[0]);
        $day=$md[2];
        $month = $str["s_month_".(int)($md[1])]; //date("M", strtotime($mdate));
    } else {
        $etime="";
        $month="";
        $day="";
    }
  
  
    $m3["mtime"] = $etime;
    
    $m3["mtime"] = $etime;
    $m3["month"] = $month;
    $m3["day"] = $md[2];
    $m3["thumb"] = $thumb;
    $m3["thumb2"] = $thumb2;

    //$m3["number"] = $arr[$i];
    
    if ($i == 0 ){
        $m3["tag"] = '<h1 class="page-slogan caps-ultra">';
        $m3["tag2"] = '</h1>';
        //$m3["tag"] = '<div class="page-slogan caps-ultra">';

        //$m3["tag2"] = '</div>';
    }
    else{
       // $m3["tag"] = '<h2 >';
      //  $m3["tag2"] = '</h2>';
       $m3["tag"] = '<div class="page-slogan caps-ultra">';

      $m3["tag2"] = '</div>';
    }
    $m2["slider_items"].=load_template("main_slider_item",$m3);
}

$m1["sliders"]=load_template("main_slider",$m2);
 
?>