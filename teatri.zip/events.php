<?php

$uri = $_SERVER['REQUEST_URI'];
// Save the URI to the session
$_SESSION['saved_addr'] = $uri;

$m1["content"] = "";
$m1["events_item"] = "";

$current_datetime = date('Y-m-d H:i:s');

if($lang == 1){
    $meta_name = '"თეატრის" ბილეთები & ღონისძიებები';
    $meta_desc = 'შეიძინეთ "თეატრის" ბილეთები და გაეცანით ინფორმაციას სივრცეში მიმდინარე ღონისძიებების შესხებ.';
    $fb_image=$main_domain."/images/corporate-fb.png";

}
else{
    $meta_name = '"Theatre" Tickets & Events';
    $meta_desc = 'Buy "Theatre" tickets and learn about the events planned in the space.';
    $fb_image=$main_domain."/images/corporate-fb.png";
}

$q = "SELECT * FROM articles WHERE  cat='1121' and status='1' and mdate >  '$current_datetime' ORDER BY mdate ASC, id DESC";
$r = mysqli_query($conn, $q) or die(mysqli_error($conn));
$arr = ['first','second','third'];

$num_rows = mysqli_num_rows($r);
$m3["mtext"]="";

$q2 = "SELECT * FROM articles WHERE  cat='1121' and status='1' and mdate >  '$current_datetime' ORDER BY mdate ASC, id DESC";
$r2 = mysqli_query($conn, $q2) or die(mysqli_error($conn));
$num_main_event = mysqli_num_rows($r2);

for ($i = 0; $i < $num_rows; $i++) {
    $fid = mr($r, $i, "front_id");
    if($fid == 'y9nkSTl9yV'){
        $m2['time_show'] = 'none';
    }else{
        $m2['time_show'] = 'block';
    }
    $link_en =mr($r, $i, "link_en");  
    $link =mr($r, $i,  "link"); 
    $mdate=mr($r, $i, "mdate");   
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl2 = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='1'") or die(mysqli_error($conn));

    $rl_num_rows = mysqli_num_rows($rl);
    $mid = mr($r, $i, "id");

    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
        $fid = mr($rl, 0, "front_id");
    } else {
        $mtitle = mr($r, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        $fid = mr($r, $i, "front_id");
    }       
    $event_type = mr($r, $i, "event_type");

    if ($link!=""){
        if ($lang == 1){
            $m2['link'] = $link;
        }
        else {
            $m2['link'] = $link_en;
        }
    } else {
        $plink=mr($r, $i, "p_link");
        
        if ($plink==""){
            $m2['link']="/booking/$lang_names[$lang]?id=".$fid;
        } else {
            $m2["link"]="/".$plink."/".$lang_names[$lang];
        }
        
    }
        $roomid = mr($rl2, 0, "room_id");


        
		$rsk=mysqli_query($conn, "SELECT * FROM tables WHERE room_id='$roomid' and isactive='1'") or die(mysqli_error($conn));

		$skraod=0;
		for ($j=0;$j<mysqli_num_rows($rsk);$j++){
	
		$tid=mr($rsk, $j, "id");

		for ($ii=1;$ii<=10;$ii++){
		$rc=mysqli_query($conn, "SELECT * FROM chairs WHERE table_id='$tid' and chair_id='$ii' and isactive='1'") or die(mysqli_error($conn));
		$skraod+=mysqli_num_rows($rc);
		}
    }
		
        $rsk=mysqli_query($conn, "SELECT * FROM `orders` where orders.event_id = $mid and is_payed = 1;") or die(mysqli_error($conn));

        $m2["title"] = $mtitle;
        $m2["mtext"] = $mtext;
        $m2["mtext"]=str_replace("[a]","'",$m2["mtext"]);
        $m2["title"]=str_replace("[a]","'",$m2["title"]);
        $m2["lang"]=$lang;
        $thumb = get_file($mid,1);
        $gallery=build_gallery($mid, 4);
        $thumb_desc=get_file_desc($mid, 1);
        $m2["mthumb_desc"]=$thumb_desc;
        $thumb_desc=get_file_desc($mid,4);
	    $m2["thumb_desc"]=$thumb_desc;

        $m2["mtext"]=str_replace("[gallery]",$gallery,$m2["mtext"]);
    
        
        if($mdate!=""){
            $md=explode(" ",$mdate);
            $etime = $md[1];
            $etime = explode(":",$etime);
            $etime = $etime[0].":".$etime[1]; 
            $md=explode("-",$md[0]);
            $month = $str["s_month_".ltrim($md[1], "0")];//  date("M", strtotime($mdate));
            $day=$md[2];
        } else {
            $month="";
            $etime="";
            $day="";
        }
     
      
        

        $m2["time"] = $etime;
        $m2["month"] = $month;
        $m2["day"] = $day;
        $m2["thumb"] = $thumb;
        //$m2["number"] = $arr[$i];
        
        
        if($event_type == 1){	


            $event_type = mr($r, $i, "event_type");

            $bil_raod_1=mr($r, $i, "bil_raod_1");
            $bil_raod_2=mr($r, $i, "bil_raod_2");
            $bil_raod_3=mr($r, $i, "bil_raod_3");

            $ral1=mysqli_query($conn, "SELECT * FROM orders WHERE event_id='$mid' AND ticket_type = '1' AND is_payed='1'") or die(mysqli_error($conn));
            $ral2=mysqli_query($conn, "SELECT * FROM orders WHERE event_id='$mid' AND ticket_type = '2' AND is_payed='1'") or die(mysqli_error($conn));
            $ral3=mysqli_query($conn, "SELECT * FROM orders WHERE event_id='$mid' AND ticket_type = '3' AND is_payed='1'") or die(mysqli_error($conn));
            $ral1_r=mysqli_num_rows($ral1);
            $ral2_r=mysqli_num_rows($ral2);
            $ral3_r=mysqli_num_rows($ral3);
            $tick = $ral1_r + $ral2_r + $ral3_r;
            
            $btick = $bil_raod_1 + $bil_raod_2 + $bil_raod_3;
            if ($tick >=$btick ){
                $m1["events_item"].=load_template("events_item_sold",$m2);

            }else{
                $m1["events_item"].=load_template("events_item",$m2);
    
            }
        }else{

        if (mysqli_num_rows($rsk) >= $skraod){
            $m1["events_item"].=load_template("events_item_sold",$m2);

        }else{
            $m1["events_item"].=load_template("events_item",$m2);

        }
    }
}
$m2["numb"] = $num_main_event; 

$fb_text=$str["s_fb_title_events"];
$fb_site_desc=$str["s_fb_desc_events"];

if (!isset($event_background)){
    $m1["content"]=load_template("events",$m2);
} else {
    $m2["event_background"]=load_template("events",$m2);
}

if($lang == 1){
    $breadname = 'ღონისძიებები';
}
else{
    $breadname = 'Events';
}

$fb_url='https://teatri.ge/events/';


$breadcrumbItem = [
    '@type' => 'ListItem',
    'position' => 2,
    'item' => [
        '@id' => 'https://teatri.ge/events/',
        'name' => $breadname
    ]
];
array_push($breadcrumbList['itemListElement'], $breadcrumbItem);



?>