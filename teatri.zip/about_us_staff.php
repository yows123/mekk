<?php
$q = "SELECT * FROM articles WHERE  cat='401'  ORDER BY mdate  Limit 10";
$r = mysqli_query($conn, $q) or die(mysqli_error($conn));

$num_rows = mysqli_num_rows($r);
$m2["staff_item"]="";
for ($i = 0; $i < $num_rows; $i++) {
    $fid = mr($r, $i, "front_id");
    $rl = mysqli_query($conn, "SELECT * FROM articles WHERE front_id='$fid' and lang='$lang'") or die(mysqli_error($conn));
    $rl_num_rows = mysqli_num_rows($rl);

    if ($rl_num_rows > 0) {
        $mtitle = mr($rl, 0, "mtitle");
        $mtext = mr($rl, 0, "mtext");
        $pname = mr($rl, 0, "pname");
        $fid = mr($r, 0, "front_id");
        $link = mr($rl, 0, "link");
    } else {
        $mtitle = mr($rl, $i, "mtitle");
        $mtext = mr($r, $i, "mtext");
        $pname = mr($r, $i, "pname");
        $fid = mr($r, $i, "front_id");
        $link = mr($rl, $i, "link");
    }


        $m3["title"] = $mtitle;
        $m3["mtext"] = $mtext;
        $m3["pname"] = $pname;
        $m3["mtext"]=str_replace("[a]","'",$m3["mtext"]);
        $m3["pname"]=str_replace("[a]","'",$m3["pname"]);
        $m3["title"]=str_replace("[a]","'",$m3["title"]);
        $m3["lang"]=$lang;
        $m3["link"]=$link;

        $mid = mr($r, $i, "id");
        $thumb = get_file($mid,1);
        $m3["thumb"] = $thumb;
        
        $m2["staff_item"].=load_template("about_us_staff_item",$m3);
    
}



?>