<?php

if($lang == 1){
    $breadname = 'დასი';
}
else{
    $breadname = 'TROUPE';
}


$breadcrumbItem = [
    '@type' => 'ListItem',
    'position' => 2,
    'item' => [
        '@id' => 'https://teatri.ge/group/',
        'name' => $breadname
    ]
];
array_push($breadcrumbList['itemListElement'], $breadcrumbItem);




$uri = $_SERVER['REQUEST_URI'];
// Save the URI to the session
$_SESSION['saved_addr'] = $uri;

$pid=371;

include "text_page.php";

$fb_url = 'https://teatri.ge/group/';

?>