<?php

if($lang == 1){
    $m1["langf"]="";
}
else{
    $m1["langf"]="en";
}

include "home_main_events.php";

include "home_events.php";

include "run_line.php";

include "home_news.php";

include "home_about_us.php";

include "main_slider.php";

include "home_menu.php";

//include "upcomingevents.php";

$fb_text=$str["s_fb_title_home"];
$fb_site_desc=$str["s_fb_desc_home"];

$m1["content"]=load_template("home", $m1);


?>